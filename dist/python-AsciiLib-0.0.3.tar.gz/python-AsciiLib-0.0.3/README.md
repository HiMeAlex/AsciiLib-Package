AsciiLib
by: Alexander J.

AsciiLib is a module for converting visual medias (jpg, png, mp4, etc.) into ascii art versions

Dependencies: os, numpy, pathlib, pillow, and cv2 (A.K.A OpenCV)